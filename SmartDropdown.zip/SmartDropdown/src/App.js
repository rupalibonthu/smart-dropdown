import React, { Component, useDebugValue } from 'react';
import SearchCountry from './Components/searchCountry';
import './App.css';

class App extends Component {

  state = {
    countries: ["India ", "Australia", "USA", "Canada"],
    userauthentication: true,
    showItems: 2,
    remainingItem: 2
  }

  handleShowMore = (event) => {
    event.preventDefault();
    this.setState({
      showItems:
        this.state.showItems >= this.state.countries.length ?
          this.state.showItems : this.state.showItems + (this.state.countries.length - this.state.showItems),
      remainingItem: this.state.countries.length - this.state.showItems
    })
  }


  AddInput = (contnew, ileftnew) => {
    let countriesNew = this.state.countries.concat(contnew)
    let itemleftNew = parseInt(this.state.remainingItem + ileftnew)
    this.setState(

      { ...this.state, countries: countriesNew, remainingItem: itemleftNew }, () => {
        console.log(this.state.countries, 'countries');

      })
   
  }
  handleCheck = () => {
    this.setState({ userauthentication: !this.state.userauthentication });
  }

  render() {


    return (
      <div className="container-fluid">
        <h2>Smart Dropdown</h2>
        <div className="dropdown-box">
          <div className="heading">Search A Location</div>
          {/* <SearchCountry country={() => [ "India ", "Australia","USA", "Canada" ]}/> */}

          <SearchCountry country={this.state.countries}
            changed={this.AddInput}
            authenticated={this.state.userauthentication}
            checked={this.handleCheck}
            showitems={this.handleShowMore}
            stateshowitems={this.state.showItems}
            itemleft={this.state.remainingItem} />
        </div>
      </div>

    )
  }

}

export default App;
