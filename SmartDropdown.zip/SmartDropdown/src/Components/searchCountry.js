import React, { Component } from 'react';
import "./searchCountry.css";

class SearchCountry extends Component {
  constructor(props) {
    super(props)
    this.state = {
      selected: ''
    }
  }
  handleChange = (e) => {
    this.setState({ selected: e.target.value });
  }


  render() {
   
    const items = this.props.country.slice(0, this.props.stateshowitems).map((item, i) =>
      <option key={i}>
        {item}
      </option>)
    return (
      <div>
        {/*         <select value={this.state.selected} 
        onChange={this.handleChange} >{this.props.country().map((param, i) =>
                    <option key={i}>
                        {param}
                    </option>)}
        </select>
        <p>Search:<input type="text" value={this.state.selected} onChange={this.inputChange}></input></p> */}
        <div>
          <i class="fa fa-search search-icon" aria-hidden="true" ></i>
          <input list="hosting-plan" type="text" value={this.state.selected} onChange={this.handleChange} placeholder="Search..." />
          <datalist id="hosting-plan"  >

            {items}

          </datalist>

        </div>
        <input style={{ marginTop: "100px" }} type="checkbox" onChange={this.props.checked} checked={this.props.authenticated} /> :User Privilege
        <button className={this.props.authenticated ? "display-button" : "invisible-button "} onClick={() => this.props.changed(this.state.selected, 1)}>Add &amp; Select</button><br />
        <span className="showmore" onClick={this.props.showitems}>
          {this.props.itemleft} more!
        </span>
      </div>

    )
  }

}

export default SearchCountry;